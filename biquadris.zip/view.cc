#include "view.h"

View::~View(){}
